package practico4;

public class P4Ejercicio4 {
    
    public int MinimoElemArray(int[] arr, int i, int min){
        int ret = Integer.MAX_VALUE;
        if (i > arr.length){
           ret = min; 
        }
        else{
            
        }
        return 0;
    }
    
    
}
